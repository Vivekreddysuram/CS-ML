			                         README
Steps for executing:
1: Open the hw7.py or hw7.ipynb file from the zip file.
2: Make sure that the data file is loaded properly.
3: Preferable if the file is opened in Collab.
4: The Python version should be 3.10 or higher.
5: Once the code is executed the output is displayed.
6: REPORT.pdf is the pdf file.

